class StringResource
{
  static var TXT_PASSWORD = "Password";
}