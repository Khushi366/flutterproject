class DimenResources
{
  static var TXT_RADIUS = 10.0;
}