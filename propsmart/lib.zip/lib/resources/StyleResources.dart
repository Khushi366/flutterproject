import 'package:flutter/material.dart';

class StyleResources
{
  static Color BTN_COLOR =  Colors.red;
  static TextStyle BTN_TEXT_STYLE = TextStyle(color: Colors.white,fontSize: 16.0,fontWeight: FontWeight.bold,letterSpacing: 2.0);
}